// Variables
let name = "John";
let age = 30;

// Functions
function sayHello(name) {
  console.log("Hello " + name);
}

// Function Calls
sayHello(name);

//注册登录
// Add Event Listener for Register/Login Button
let registerLoginButton = document.querySelector(".register-login a");
registerLoginButton.addEventListener("click", function () {
  // Add Your Code Here
});
